using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class ActiveCheck : MonoBehaviour
{
    public GameObject panelActive;
    public TMP_InputField inputField;
    private int a;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Return) && a == 1)
        {
            inputField.ActivateInputField(); //ä��â Ȱ��ȭ �� �ѹ� ����Ű �������� Ȱ��ȭ
        }

        if ( (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.Tab) ) && panelActive.activeSelf == false)
        {
            panelActive.SetActive(true);
            a = 1;
        }  
        else if (Input.GetKeyDown(KeyCode.Tab) && panelActive.activeSelf == true)
        {
            panelActive.SetActive(false);
            a = 0;
        }

        
            
    }
}
