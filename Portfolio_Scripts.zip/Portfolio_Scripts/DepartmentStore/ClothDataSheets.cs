using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
public class ClothDataSheets : MonoBehaviour
{
    public Sprite clothImage; // cloth image source
    public int clothCost;
    public string demonstration;

    public Image imageBox;  // source image import to UI Image object
    public TMP_Text demonstrationBox; //TextMeshProUGUI �� �ؽ�Ʈ�� �ٲܼ��� �־ text������Ʈ�� �������� ���Ѵ�.
    public TMP_Text costBox;
    
    void OnEnable()
    {
        imageBox.sprite = clothImage;
        costBox.text = clothCost.ToString() + " $";
        demonstrationBox.text = demonstration;
    }
}
