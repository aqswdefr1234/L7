using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MenuButtonEvents : MonoBehaviour
{
    public GameObject menuPanel;
    private int menuClickCount;

    void Start()
    {
        menuClickCount = 0;
    }
    public void menuButton_PanelActive()
    {
        if (menuClickCount % 2 == 0) // �ѹ� �������� ����
        {
            menuPanel.SetActive(true);
        }
        if (menuClickCount % 2 == 1) // �ι� ������ �� ����
        {
            menuPanel.SetActive(false);
        }
        menuClickCount++;
    }
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.G))
        {
            if (menuClickCount % 2 == 0) // �ѹ� �������� ����
            {
                menuPanel.SetActive(true);
                Cursor.lockState = CursorLockMode.None;
            }
            if (menuClickCount % 2 == 1) // �ι� ������ �� ����
            {
                menuPanel.SetActive(false);
                Cursor.lockState = CursorLockMode.Locked;
            }
            menuClickCount++;
        }
    }
    public void URLBtn()
    {
        Application.OpenURL("https://kimlim9434.wixsite.com/chocolatebread");
    }
}
